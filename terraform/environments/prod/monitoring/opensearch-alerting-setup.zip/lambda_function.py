"""
OpenSearch Alerting Setup Lambda
Creates notification channels and monitors for log-based alerting.
Uses AWS Sigv4 authentication for secure OpenSearch access.
"""

import json
import os
import logging
from typing import Any
from datetime import datetime
import hashlib
import hmac
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
import ssl

# Configure logging
logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Environment variables
OPENSEARCH_ENDPOINT = os.environ.get('OPENSEARCH_ENDPOINT', '')
SNS_TOPIC_CRITICAL = os.environ.get('SNS_TOPIC_CRITICAL', '')
SNS_TOPIC_WARNING = os.environ.get('SNS_TOPIC_WARNING', '')
SNS_TOPIC_INFO = os.environ.get('SNS_TOPIC_INFO', '')
SNS_ROLE_ARN = os.environ.get('SNS_ROLE_ARN', '')
AWS_REGION_NAME = os.environ.get('AWS_REGION_NAME', 'ap-northeast-2')

# Index pattern for ECS logs
LOG_INDEX_PATTERN = "ecs-logs-*"


def sign(key: bytes, msg: str) -> bytes:
    """Create HMAC-SHA256 signature."""
    return hmac.new(key, msg.encode('utf-8'), hashlib.sha256).digest()


def get_signature_key(key: str, date_stamp: str, region: str, service: str) -> bytes:
    """Derive signing key for AWS Sigv4."""
    k_date = sign(('AWS4' + key).encode('utf-8'), date_stamp)
    k_region = sign(k_date, region)
    k_service = sign(k_region, service)
    k_signing = sign(k_service, 'aws4_request')
    return k_signing


def create_sigv4_headers(method: str, url: str, body: str | None, region: str) -> dict:
    """Create AWS Sigv4 signed headers for OpenSearch request."""
    # Get credentials from Lambda environment
    access_key = os.environ.get('AWS_ACCESS_KEY_ID', '')
    secret_key = os.environ.get('AWS_SECRET_ACCESS_KEY', '')
    session_token = os.environ.get('AWS_SESSION_TOKEN', '')

    service = 'es'
    parsed_url = urlparse(url)
    host = parsed_url.netloc
    canonical_uri = parsed_url.path or '/'
    canonical_querystring = parsed_url.query or ''

    t = datetime.utcnow()
    amz_date = t.strftime('%Y%m%dT%H%M%SZ')
    date_stamp = t.strftime('%Y%m%d')

    # Create payload hash
    payload = body if body else ''
    payload_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()

    # Create canonical headers
    canonical_headers = f'host:{host}\nx-amz-date:{amz_date}\n'
    signed_headers = 'host;x-amz-date'

    if session_token:
        canonical_headers = f'host:{host}\nx-amz-date:{amz_date}\nx-amz-security-token:{session_token}\n'
        signed_headers = 'host;x-amz-date;x-amz-security-token'

    # Create canonical request
    canonical_request = '\n'.join([
        method,
        canonical_uri,
        canonical_querystring,
        canonical_headers,
        signed_headers,
        payload_hash
    ])

    # Create string to sign
    algorithm = 'AWS4-HMAC-SHA256'
    credential_scope = f'{date_stamp}/{region}/{service}/aws4_request'
    string_to_sign = '\n'.join([
        algorithm,
        amz_date,
        credential_scope,
        hashlib.sha256(canonical_request.encode('utf-8')).hexdigest()
    ])

    # Create signature
    signing_key = get_signature_key(secret_key, date_stamp, region, service)
    signature = hmac.new(signing_key, string_to_sign.encode('utf-8'), hashlib.sha256).hexdigest()

    # Create authorization header
    authorization_header = (
        f'{algorithm} Credential={access_key}/{credential_scope}, '
        f'SignedHeaders={signed_headers}, Signature={signature}'
    )

    headers = {
        'Content-Type': 'application/json',
        'X-Amz-Date': amz_date,
        'Authorization': authorization_header,
    }

    if session_token:
        headers['X-Amz-Security-Token'] = session_token

    return headers


def make_opensearch_request(method: str, path: str, body: dict | None = None) -> dict:
    """Make AWS Sigv4 authenticated request to OpenSearch."""
    url = f"{OPENSEARCH_ENDPOINT}{path}"

    body_str = json.dumps(body) if body else None

    headers = create_sigv4_headers(method, url, body_str, AWS_REGION_NAME)

    data = body_str.encode('utf-8') if body_str else None

    # Create SSL context
    ctx = ssl.create_default_context()

    request = Request(url, data=data, headers=headers, method=method)

    try:
        with urlopen(request, context=ctx, timeout=30) as response:
            return json.loads(response.read().decode('utf-8'))
    except HTTPError as e:
        error_body = e.read().decode('utf-8') if e.fp else str(e)
        logger.error(f"HTTP Error {e.code}: {error_body}")
        raise
    except URLError as e:
        logger.error(f"URL Error: {e.reason}")
        raise


def create_sns_destination(name: str, topic_arn: str, role_arn: str) -> str:
    """Create SNS notification destination in OpenSearch."""
    destination_body = {
        "name": name,
        "type": "sns",
        "sns": {
            "topic_arn": topic_arn,
            "role_arn": role_arn
        }
    }

    try:
        # Check if destination already exists
        existing = make_opensearch_request('GET', '/_plugins/_alerting/destinations')
        for dest in existing.get('destinations', []):
            if dest.get('name') == name:
                logger.info(f"Destination '{name}' already exists with ID: {dest['id']}")
                return dest['id']

        # Create new destination
        result = make_opensearch_request('POST', '/_plugins/_alerting/destinations', destination_body)
        dest_id = result.get('_id', '')
        logger.info(f"Created destination '{name}' with ID: {dest_id}")
        return dest_id
    except Exception as e:
        logger.error(f"Failed to create destination '{name}': {e}")
        raise


def create_error_log_monitor(destination_id: str, severity: str = 'warning') -> str:
    """Create monitor for ERROR level logs."""
    monitor_name = f"ECS Error Log Monitor ({severity})"

    monitor_body = {
        "name": monitor_name,
        "type": "monitor",
        "monitor_type": "query_level_monitor",
        "enabled": True,
        "schedule": {
            "period": {
                "interval": 5,
                "unit": "MINUTES"
            }
        },
        "inputs": [{
            "search": {
                "indices": [LOG_INDEX_PATTERN],
                "query": {
                    "size": 0,
                    "query": {
                        "bool": {
                            "must": [
                                {
                                    "bool": {
                                        "should": [
                                            {"match": {"level": "ERROR"}},
                                            {"match": {"level": "error"}},
                                            {"match": {"log_level": "ERROR"}},
                                            {"match_phrase": {"message": "ERROR"}}
                                        ],
                                        "minimum_should_match": 1
                                    }
                                }
                            ],
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": "now-5m",
                                            "lte": "now"
                                        }
                                    }
                                }
                            ]
                        }
                    },
                    "aggs": {
                        "error_count": {
                            "value_count": {
                                "field": "_id"
                            }
                        }
                    }
                }
            }
        }],
        "triggers": [{
            "name": "Error threshold exceeded",
            "severity": "2" if severity == 'warning' else "1",
            "condition": {
                "script": {
                    "source": "ctx.results[0].hits.total.value > 10",
                    "lang": "painless"
                }
            },
            "actions": [{
                "name": f"Send to SNS ({severity})",
                "destination_id": destination_id,
                "message_template": {
                    "source": """
🚨 *OpenSearch Alert: Error Logs Detected*

*Alert*: {{ctx.monitor.name}}
*Severity*: """ + severity.upper() + """
*Time*: {{ctx.periodStart}} - {{ctx.periodEnd}}
*Error Count*: {{ctx.results.0.hits.total.value}} errors in last 5 minutes

*Index*: """ + LOG_INDEX_PATTERN + """
*Query*: level:ERROR OR message:ERROR

Please check OpenSearch Dashboards for details:
""" + OPENSEARCH_ENDPOINT + """/_dashboards
"""
                },
                "throttle_enabled": True,
                "throttle": {
                    "value": 10,
                    "unit": "MINUTES"
                }
            }]
        }]
    }

    try:
        # Check if monitor already exists
        search_result = make_opensearch_request('GET', '/_plugins/_alerting/monitors/_search', {
            "query": {
                "match": {
                    "monitor.name": monitor_name
                }
            }
        })

        hits = search_result.get('hits', {}).get('hits', [])
        if hits:
            existing_id = hits[0]['_id']
            logger.info(f"Monitor '{monitor_name}' already exists with ID: {existing_id}")
            # Update existing monitor
            make_opensearch_request('PUT', f'/_plugins/_alerting/monitors/{existing_id}', monitor_body)
            logger.info(f"Updated monitor '{monitor_name}'")
            return existing_id

        # Create new monitor
        result = make_opensearch_request('POST', '/_plugins/_alerting/monitors', monitor_body)
        monitor_id = result.get('_id', '')
        logger.info(f"Created monitor '{monitor_name}' with ID: {monitor_id}")
        return monitor_id
    except Exception as e:
        logger.error(f"Failed to create monitor '{monitor_name}': {e}")
        raise


def create_exception_monitor(destination_id: str) -> str:
    """Create monitor for Exception patterns in logs."""
    monitor_name = "ECS Exception Pattern Monitor"

    monitor_body = {
        "name": monitor_name,
        "type": "monitor",
        "monitor_type": "query_level_monitor",
        "enabled": True,
        "schedule": {
            "period": {
                "interval": 1,
                "unit": "MINUTES"
            }
        },
        "inputs": [{
            "search": {
                "indices": [LOG_INDEX_PATTERN],
                "query": {
                    "size": 5,
                    "query": {
                        "bool": {
                            "must": [
                                {
                                    "bool": {
                                        "should": [
                                            {"match_phrase": {"message": "Exception"}},
                                            {"match_phrase": {"message": "Traceback"}},
                                            {"match_phrase": {"message": "Fatal"}},
                                            {"match_phrase": {"message": "FATAL"}},
                                            {"match_phrase": {"message": "OutOfMemoryError"}},
                                            {"match_phrase": {"message": "StackOverflowError"}}
                                        ],
                                        "minimum_should_match": 1
                                    }
                                }
                            ],
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": "now-1m",
                                            "lte": "now"
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        }],
        "triggers": [{
            "name": "Critical exception detected",
            "severity": "1",
            "condition": {
                "script": {
                    "source": "ctx.results[0].hits.total.value > 0",
                    "lang": "painless"
                }
            },
            "actions": [{
                "name": "Send to SNS (critical)",
                "destination_id": destination_id,
                "message_template": {
                    "source": """
🔥 *OpenSearch Alert: Critical Exception Detected*

*Alert*: {{ctx.monitor.name}}
*Severity*: CRITICAL
*Time*: {{ctx.periodStart}} - {{ctx.periodEnd}}
*Exception Count*: {{ctx.results.0.hits.total.value}} exceptions detected

*Pattern Matched*: Exception, Traceback, Fatal, OutOfMemoryError, StackOverflowError

*Sample Log Entries*:
{{#ctx.results.0.hits.hits}}
- Service: {{_source.service}} | Message: {{_source.message}}
{{/ctx.results.0.hits.hits}}

Please investigate immediately!
OpenSearch Dashboards: """ + OPENSEARCH_ENDPOINT + """/_dashboards
"""
                },
                "throttle_enabled": True,
                "throttle": {
                    "value": 5,
                    "unit": "MINUTES"
                }
            }]
        }]
    }

    try:
        # Check if monitor already exists
        search_result = make_opensearch_request('GET', '/_plugins/_alerting/monitors/_search', {
            "query": {
                "match": {
                    "monitor.name": monitor_name
                }
            }
        })

        hits = search_result.get('hits', {}).get('hits', [])
        if hits:
            existing_id = hits[0]['_id']
            logger.info(f"Monitor '{monitor_name}' already exists with ID: {existing_id}")
            make_opensearch_request('PUT', f'/_plugins/_alerting/monitors/{existing_id}', monitor_body)
            logger.info(f"Updated monitor '{monitor_name}'")
            return existing_id

        result = make_opensearch_request('POST', '/_plugins/_alerting/monitors', monitor_body)
        monitor_id = result.get('_id', '')
        logger.info(f"Created monitor '{monitor_name}' with ID: {monitor_id}")
        return monitor_id
    except Exception as e:
        logger.error(f"Failed to create monitor '{monitor_name}': {e}")
        raise


def create_service_error_rate_monitor(destination_id: str, service_name: str) -> str:
    """Create monitor for high error rate per service."""
    monitor_name = f"Service Error Rate Monitor - {service_name}"

    monitor_body = {
        "name": monitor_name,
        "type": "monitor",
        "monitor_type": "query_level_monitor",
        "enabled": True,
        "schedule": {
            "period": {
                "interval": 5,
                "unit": "MINUTES"
            }
        },
        "inputs": [{
            "search": {
                "indices": [LOG_INDEX_PATTERN],
                "query": {
                    "size": 0,
                    "query": {
                        "bool": {
                            "must": [
                                {"match": {"service": service_name}},
                                {
                                    "bool": {
                                        "should": [
                                            {"match": {"level": "ERROR"}},
                                            {"match": {"level": "error"}}
                                        ],
                                        "minimum_should_match": 1
                                    }
                                }
                            ],
                            "filter": [
                                {
                                    "range": {
                                        "@timestamp": {
                                            "gte": "now-5m",
                                            "lte": "now"
                                        }
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        }],
        "triggers": [{
            "name": f"{service_name} error rate high",
            "severity": "2",
            "condition": {
                "script": {
                    "source": "ctx.results[0].hits.total.value > 5",
                    "lang": "painless"
                }
            },
            "actions": [{
                "name": "Send to SNS (warning)",
                "destination_id": destination_id,
                "message_template": {
                    "source": f"""
⚠️ *OpenSearch Alert: High Error Rate*

*Service*: {service_name}
*Alert*: {{{{ctx.monitor.name}}}}
*Time*: {{{{ctx.periodStart}}}} - {{{{ctx.periodEnd}}}}
*Error Count*: {{{{ctx.results.0.hits.total.value}}}} errors in last 5 minutes

Please check the service logs for details.
"""
                },
                "throttle_enabled": True,
                "throttle": {
                    "value": 15,
                    "unit": "MINUTES"
                }
            }]
        }]
    }

    try:
        search_result = make_opensearch_request('GET', '/_plugins/_alerting/monitors/_search', {
            "query": {
                "match": {
                    "monitor.name": monitor_name
                }
            }
        })

        hits = search_result.get('hits', {}).get('hits', [])
        if hits:
            existing_id = hits[0]['_id']
            make_opensearch_request('PUT', f'/_plugins/_alerting/monitors/{existing_id}', monitor_body)
            logger.info(f"Updated monitor '{monitor_name}'")
            return existing_id

        result = make_opensearch_request('POST', '/_plugins/_alerting/monitors', monitor_body)
        monitor_id = result.get('_id', '')
        logger.info(f"Created monitor '{monitor_name}' with ID: {monitor_id}")
        return monitor_id
    except Exception as e:
        logger.error(f"Failed to create monitor '{monitor_name}': {e}")
        raise


def setup_all_alerting() -> dict:
    """Set up all notification channels and monitors."""
    results = {
        'destinations': {},
        'monitors': {},
        'errors': []
    }

    # Create SNS destinations
    try:
        critical_dest = create_sns_destination('SNS-Critical', SNS_TOPIC_CRITICAL, SNS_ROLE_ARN)
        results['destinations']['critical'] = critical_dest
    except Exception as e:
        results['errors'].append(f"Failed to create critical destination: {e}")
        critical_dest = None

    try:
        warning_dest = create_sns_destination('SNS-Warning', SNS_TOPIC_WARNING, SNS_ROLE_ARN)
        results['destinations']['warning'] = warning_dest
    except Exception as e:
        results['errors'].append(f"Failed to create warning destination: {e}")
        warning_dest = None

    try:
        info_dest = create_sns_destination('SNS-Info', SNS_TOPIC_INFO, SNS_ROLE_ARN)
        results['destinations']['info'] = info_dest
    except Exception as e:
        results['errors'].append(f"Failed to create info destination: {e}")
        info_dest = None

    # Create monitors
    if warning_dest:
        try:
            results['monitors']['error_log'] = create_error_log_monitor(warning_dest, 'warning')
        except Exception as e:
            results['errors'].append(f"Failed to create error log monitor: {e}")

    if critical_dest:
        try:
            results['monitors']['exception'] = create_exception_monitor(critical_dest)
        except Exception as e:
            results['errors'].append(f"Failed to create exception monitor: {e}")

    # Create per-service monitors for key services
    services = ['gateway', 'authhub', 'commerce', 'crawlinghub', 'fileflow']
    if warning_dest:
        for service in services:
            try:
                results['monitors'][f'service_{service}'] = create_service_error_rate_monitor(warning_dest, service)
            except Exception as e:
                results['errors'].append(f"Failed to create monitor for {service}: {e}")

    return results


def list_monitors() -> dict:
    """List all existing monitors."""
    try:
        result = make_opensearch_request('GET', '/_plugins/_alerting/monitors/_search', {
            "size": 100,
            "query": {"match_all": {}}
        })
        monitors = []
        for hit in result.get('hits', {}).get('hits', []):
            source = hit.get('_source', {}).get('monitor', {})
            monitors.append({
                'id': hit.get('_id'),
                'name': source.get('name'),
                'enabled': source.get('enabled'),
                'type': source.get('monitor_type')
            })
        return {'monitors': monitors}
    except Exception as e:
        return {'error': str(e)}


def list_destinations() -> dict:
    """List all existing destinations."""
    try:
        result = make_opensearch_request('GET', '/_plugins/_alerting/destinations')
        return {'destinations': result.get('destinations', [])}
    except Exception as e:
        return {'error': str(e)}


def handler(event: dict, context: Any) -> dict:
    """Lambda handler for OpenSearch alerting setup."""
    logger.info(f"Received event: {json.dumps(event)}")

    action = event.get('action', 'setup_all')

    if action == 'setup_all':
        result = setup_all_alerting()
    elif action == 'list_monitors':
        result = list_monitors()
    elif action == 'list_destinations':
        result = list_destinations()
    else:
        result = {'error': f"Unknown action: {action}"}

    logger.info(f"Result: {json.dumps(result, default=str)}")

    return {
        'statusCode': 200 if 'error' not in result else 500,
        'body': json.dumps(result, default=str)
    }
